# Termia: cómo obtener el APK (sin computadora)

Necesitás una cuenta gratis de GitHub (github.com). Todo se hace desde el navegador del celular.

1. Creá un repositorio nuevo (botón "+" > New repository). Ponele de nombre `termia`. Podés dejarlo privado.
2. Dentro del repositorio: Add file > Create new file.
   - En el nombre escribí exactamente `.github/workflows/build-apk.yml` (al escribir la barra `/` se crean las carpetas).
   - Pegá todo el contenido del archivo `build-apk.yml` y tocá Commit changes.
3. Repetí con otro archivo nuevo:
   - Nombre: `www/index.html`
   - Pegá todo el contenido del archivo `index.html` y tocá Commit changes.
4. Entrá a la pestaña **Actions**. Se va a ejecutar solo "Compilar APK de Termia" (tarda unos 6 a 10 minutos). Si no arranca, tocá "Run workflow".
5. Cuando termine con tilde verde, entrá a **Releases** (en la página principal del repositorio) y descargá `termia.apk`.
6. Abrí el archivo en el celular. Android te va a pedir permitir "instalar apps desconocidas" para el navegador o el gestor de archivos. Aceptá y listo.

Si Actions marca error en rojo, abrí el paso que falló, copiá las últimas líneas del registro y pasámelas.

## Permisos dentro de la app

- Brillo: al tocar "Forzar enfriado" aparece un botón para dar el permiso "Modificar ajustes del sistema". Se da una vez.
- Ahorro de energía: necesita un permiso especial que solo se da con una computadora (instrucciones en Ajustes de la app). Sin eso, el resto del enfriado funciona igual.
- Para enlazar celulares, los dos tienen que tener Termia abierta y estar en la misma WiFi.
